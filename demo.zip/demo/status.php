<?php 
session_start();
require "connect.php";

$user_id = $_SESSION['user']['id'];

$exam_user = "SELECT * FROM `application` WHERE `user_id` = '$user_id'";
$result = mysqli_query($connect, $exam_user); 
$resp = $result->fetch_all(MYSQLI_ASSOC);


if($_SESSION['user']['login']) {} else {
    header('Location: '. 'index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Починим!</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include ("components/Header/header.php"); ?>
    <div class="container">
        <?php 
        if(count($resp) == 0) {
            echo "<h1 style='color: orange; text-align: center; margin-top: 40px;'>У вас еще нету заявок</h1>";
        }
            for ($i=0; $i < count($resp); $i++) {

        ?> 
        <div class="item">
            <div class="data">
                <h2><?= $resp[$i]['name'] ?></h2>
                <p style="margin-bottom: 20px; word-wrap: break-word; width: 530px;"><?= $resp[$i]['description'] ?></p>
                <h3>Статус: 
                    <?php if($resp[$i]['status'] == "Одобрено") { echo "<style> .y {color: green} </style>"; ?><span class="y"><?= $resp[$i]['status'] ?></span> <?php } ?>
                    <?php if($resp[$i]['status'] == "Ожидание") { echo "<style> .x {color: #ffa100} </style>"; ?><span class="x"><?= $resp[$i]['status'] ?></span> <?php } ?>
                    <?php if($resp[$i]['status'] == "Отказ") { echo "<style> .z {color: red} </style>"; ?><span class="z"><?= $resp[$i]['status'] ?></span> <?php } ?>
                </h3>
                <?php if($resp[$i]['comment']) { ?> <p style="margin-bottom: 20px; word-wrap: break-word; width: 530px;">Комментрий: <?= $resp[$i]['comment'] ?></p> <?php }?>
            </div>
        </div>
        <?php } ?>
    </div>
</body>
</html>