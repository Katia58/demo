<?php 

require "connect.php";

$exam_user = "SELECT * FROM `application` WHERE `status` = 'Одобрено'";
$result = mysqli_query($connect, $exam_user); 
$resp = $result->fetch_all(MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Починим!</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container"  style="margin-top: 80px;">
        <h1 style="text-align: center; font-size: 100px;">ПОЧИНИМ!</h1>
        <p style="text-align: center; font-size: 40px;">Этой информационная система, которая позволяет<br>записаться в сервис для ремонта машины!</p>
        <div class="inner" style="margin-top: 80px;">
            <div>
                <p style="font-size: 27px;">Если вы уже зарегистрированы на нашем<br> портале, можете авторизоваться</p>
               <div style="margin-top: 60px;">
                <a class="btn" href="auth.php">Авторизация</a>
               </div>
            </div>
            <div style="border: 1px dashed lightgrey;"></div>
            <div>
            <p style="font-size: 27px;">Если вы посетили сайт впервые, можете<br>зарегистрироваться</p>
            <div style="margin-top: 60px;">
            <a class="btn" href="reg.php">Регистрация</a>
            </div>
            </div>
        </div>
    </div>
</body>
</html>