<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="inner">
                <div></div>
                <a class="header__logo" href="/"><h1 style="text-align: center; font-size: 80px;">ПОЧИНИМ!</h1></a>
                <a class="btn auth" href="auth.php">Войти</a>
                <a class="auth_user" href="/profile.php">Личный кабинет</a>
                <a class="auth_user" href="/logout.php">Выйти</a>
                        <?php
                        
                        if(isset($_SESSION['login'])) {
                            echo "<style>.auth {display: none}; .auth_user {display: block;}</style>";
                        } else {
                            echo "<style>.auth_user {display: none;}</style>";
                        }
                        
                        ?>
            </div>
        </div>
    </header>
</body>
</html>