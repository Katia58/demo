<?php 

require "connect.php";
session_start();

if(isset($_POST['name']) and isset($_POST['description'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $date = $_POST['date'];
    $time = $_POST['time'];

    $user_id = $_SESSION['user']['id'];

    if (true) {
        $sql = "INSERT INTO application (name, description, date, time, user_id, status) VALUES ('$name', '$description', '$date', '$time', '$user_id', 'Ожидание')";
        $result = mysqli_query($connect, $sql);
        if($result) { 
            echo "<script>alert(' успешно отправленна на рассмотрение'); location.href='profile.php';</script>"; 
        } else { 
            echo "<script>alert('ошибка!')</script>"; 
        }    
    }
}

if($_SESSION['user']['login']) {} else {
    header('Location: '. 'index.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Починим!</title>
</head>
<body>
    <?php include ("components/Header/header.php"); ?>
    <div class="container">
        <div style="margin-top: 40px;">
            <a href="status.php" class="btn">Ваши заявки!</a>
            <?php if($_SESSION['user']['role'] == 'admin') { ?>
                <a href="/admin/index.php" class="btn">Админка</a>
            <?php }?>
        </div>
    </div>
    <form action="" method="POST" enctype="multipart/form-data">
        <h2>Подать заявку!</h2>
        <input name="name" type="text" placeholder="Название машины">
        <textarea style="padding: 10px;" name="description" id="" cols="30" rows="10" placeholder="Описание"></textarea>
        <input type="date" name="date">
        <input type="time" name="time">
        <button>Отправить</button>
    </form>
</body>
</html>